# prod-files

Кастомные файлы для SHM, монтируются через docker-compose volumes.

## Файлы

| Файл | Монтируется в | Назначение |
|------|--------------|-----------|
| `Const.pm` | `/app/lib/Core/Const.pm` | Кастомные константы |
| `spool.pl` | `/app/bin/spool.pl` | Override spool — загружает DataNotify хуки |
| `WebSocketNotify.pm` | `/app/lib/Local/WebSocketNotify.pm` | Публикация событий в Redis (PUBLISH) |
| `DataNotify.pm` | `/app/lib/Local/DataNotify.pm` | Хуки на _set/_add/_delete — перехватывает ВСЕ записи в БД |
| `ws_init.pl` | `/app/lib/Local/ws_init.pm` | Автозагрузка хуков для core контейнера (через PERL5OPT) |

## Как работает

```
Любое изменение в MySQL (_set, _add, _delete)
  → DataNotify перехватывает
  → регистрирует post-commit callback
  → после commit() публикует событие в Redis (shm:events)
  → WBAP BFF подписан на shm:events
  → мгновенно пушит в WebSocket клиенту
```

Задержка: **< 200мс** от изменения до WebSocket.

## Что покрыто

| Действие | Таблица | WS событие |
|----------|---------|-----------|
| Оплата | `pays` | `balance_update` |
| Изменение баланса | `users` | `balance_update` |
| Создание/блокировка/активация услуги | `user_services` | `service_update` |
| Смена тарифа | `user_services` | `service_update` |
| Обработка задачи | `spool` | `system_notification` |
| Изменение профиля | `users` | `balance_update` |
| Любой другой INSERT/UPDATE/DELETE | * | соответствующий тип |

Пропускаются: `sessions`, `spool_history`, `configs` (системные таблицы).

## docker-compose

### core (API)

```yaml
core:
  environment:
    REDIS_HOST: redis
    REDIS_PORT: 6379
    PERL5OPT: "-MLocal::ws_init"
  volumes:
    - "./prod-files/Const.pm:/app/lib/Core/Const.pm"
    - "./prod-files/WebSocketNotify.pm:/app/lib/Local/WebSocketNotify.pm"
    - "./prod-files/DataNotify.pm:/app/lib/Local/DataNotify.pm"
    - "./prod-files/ws_init.pl:/app/lib/Local/ws_init.pm"
```

### spool

```yaml
spool:
  environment:
    REDIS_HOST: redis
    REDIS_PORT: 6379
  volumes:
    - "./prod-files/WebSocketNotify.pm:/app/lib/Local/WebSocketNotify.pm"
    - "./prod-files/DataNotify.pm:/app/lib/Local/DataNotify.pm"
    - "./prod-files/spool.pl:/app/bin/spool.pl"
```

## Env переменные

| Переменная | Значение | Описание |
|-----------|---------|----------|
| `REDIS_HOST` | `redis` | Хост Redis в docker-сети |
| `REDIS_PORT` | `6379` | Порт Redis |
| `WS_REDIS_CHANNEL` | `shm:events` | Канал (по умолчанию) |
| `PERL5OPT` | `-MLocal::ws_init` | Только для core — автозагрузка хуков |

## Формат события в Redis

```json
{
  "action": "update",
  "table": "users",
  "user_id": 123,
  "timestamp": 1774615587
}
```

`action`: `create` / `update` / `delete`
`table`: имя таблицы MySQL где произошло изменение
