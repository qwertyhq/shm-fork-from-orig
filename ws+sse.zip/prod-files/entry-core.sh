#!/bin/sh -e

cat <<EOF > /etc/environment
TZ=${TZ}
SHM_ROOT_DIR=${SHM_ROOT_DIR}
SHM_DATA_DIR=${SHM_DATA_DIR}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}
DB_HOST=${DB_HOST}
DB_PORT=${DB_PORT}
DB_NAME=${DB_NAME}
EOF

if [ "${SHM_ROLE}" = "spool" ]; then
    /app/bin/spool.pl
else
    # Create SHM database structure and fill data
    /app/bin/init.pl

    # Start Realtime server in background (if script exists)
    if [ -f /app/bin/realtime-server.pl ]; then
        perl /app/bin/realtime-server.pl &
        echo "Realtime server started on port ${WS_PORT:-9083}"
    fi

    perl /app/bin/shm-server.pl &
    test -p /tmp/shm_log || mkfifo /tmp/shm_log
    tail -f /tmp/shm_log
fi
